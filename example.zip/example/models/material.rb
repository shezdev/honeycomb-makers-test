class Material
  attr_accessor :identifier

  def initialize(identifier)
    self.identifier = identifier
  end
end
